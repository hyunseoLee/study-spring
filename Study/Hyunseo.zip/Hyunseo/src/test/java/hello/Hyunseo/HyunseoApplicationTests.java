package hello.Hyunseo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyunseoApplicationTests {

	@Test
	void contextLoads() {
	}

}
